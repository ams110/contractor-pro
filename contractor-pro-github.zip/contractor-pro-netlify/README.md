# 🏗️ Contractor Pro - קבלן פרו

نظام إدارة المقاولين - Contractor Management System

## Features
- 📊 Financial Dashboard with charts
- 🏗️ Project management with P&L
- 👷 Worker management & salary tracking
- 📅 Work day logging with overtime calculation
- 💸 Expense tracking with VAT (17%)
- 💰 Payment tracking & worker balance
- ⚙️ Settings & data management

## Tech
- React 18 + Recharts
- RTL Arabic interface
- Dark theme
- LocalStorage persistence
- Single HTML file - no build needed

## Deploy
Upload `index.html` to any static hosting (Netlify, Vercel, GitHub Pages)
