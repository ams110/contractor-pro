# كيف ترفع المشروع على GitHub وتشغّله

## الطريقة 1: من المتصفح (بدون Terminal) ⭐

### خطوة 1: اعمل مشروع جديد على GitHub
1. روح على https://github.com/new
2. اكتب اسم المشروع: contractor-pro
3. اختار "Public"
4. ✅ علّم "Add a README file"
5. اضغط "Create repository"

### خطوة 2: ارفع الملف
1. بصفحة المشروع، اضغط "Add file" → "Upload files"
2. اسحب ملف index.html وأفلته
3. اضغط "Commit changes"

### خطوة 3: فعّل GitHub Pages
1. روح على Settings → Pages
2. بقسم "Source" اختار "Deploy from a branch"
3. اختار branch: main
4. اختار folder: / (root)
5. اضغط Save
6. استنى دقيقة - رح يعطيك رابط!

الرابط بيكون: https://اسمك.github.io/contractor-pro

---

## الطريقة 2: ربط مع Netlify
1. بعد ما ترفع على GitHub
2. روح على app.netlify.com
3. اضغط "Import from Git"
4. اختار GitHub → اختار contractor-pro
5. اضغط Deploy
6. يعطيك رابط مجاني!

---

## الطريقة 3: ربط مع Vercel
1. بعد ما ترفع على GitHub
2. روح على vercel.com
3. سجّل بحساب GitHub
4. اختار contractor-pro
5. اضغط Deploy
6. يعطيك رابط مجاني!
